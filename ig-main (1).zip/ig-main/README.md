# Perintah
    $ pkg update && upgrade
    $ pkg install git
    $ pkg install python
    $ pip install requests
    $ pip install futures
    $ git clone https://github.com/SetaGanz/ig
    $ cd ig
    $ git pull
    $ python Prem.py
